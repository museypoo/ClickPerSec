CREATE PROCEDURE `deleteOldHouses`()
  BEGIN
  DELETE FROM `houses` WHERE `owned` = 0;
END
CREATE PROCEDURE `deleteOldGangs`()
  BEGIN
  DELETE FROM `gangs` WHERE `active` = 0;
END